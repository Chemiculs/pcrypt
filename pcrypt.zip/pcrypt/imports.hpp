#pragma once
#include "defs.hpp"
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <tlhelp32.h>
#include <Psapi.h>
using namespace std;